/* IFMO Distributed Class, autumn 2013
 *
 * common.h for PA4
 * Students must not modify this file!
 */

#ifndef __IFMO_DISTRIBUTED_CLASS_COMMON__H
#define __IFMO_DISTRIBUTED_CLASS_COMMON__H

// Not extern for simplicity only
static const char * const events_log = "events.log";
static const char * const pipes_log = "pipes.log";

#endif // __IFMO_DISTRIBUTED_CLASS_PA4__COMMON__H
