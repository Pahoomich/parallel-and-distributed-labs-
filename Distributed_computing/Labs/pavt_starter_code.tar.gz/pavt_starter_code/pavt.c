#include "banking.h"

void transfer(void * parent_data, local_id src, local_id dst,
              balance_t amount)
{
    // implement by student
}

void total_sum_snapshot()
{
}

int main(int argc, char * argv[])
{
    // Don't forget to call this:
    //bank_robbery(parent_data)

    return 0;
}
